# Problem Statement: Set up MongoDB Cloud Atlas and connect to local
1. Perform all necessary steps to setup the cloud instance
2. Connect to the cloud instance of Mongo.
3. Print "Connection Successful!" on successful connection with DB
4. Print "Connection unsuccessful" if not connected.


