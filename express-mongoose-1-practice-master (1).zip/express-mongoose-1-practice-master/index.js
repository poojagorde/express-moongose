const mongoose = require('mongoose');
const dbUrl = 'mongodb+srv://student:DQVSYOJ87dGBjoBl@cluster0.8s2mz.mongodb.net/?retryWrites=true&w=majority';


const connectionParam = {
    useNewUrlParser: true,
    useUnifiedTopology: true,
};

mongoose.connect(dbUrl, connectionParam).then(() => {
    console.info("Connection successful to Mongo");
}).catch(err => {
    console.log("Error connecting to Mongo", err);
});



// new DQVSYOJ87dGBjoBl